import React, {Component} from 'react';

export default class Space extends Component {

    render (){
        return (
            <a>TODO CHANGE ME</a>
        );
    }
}