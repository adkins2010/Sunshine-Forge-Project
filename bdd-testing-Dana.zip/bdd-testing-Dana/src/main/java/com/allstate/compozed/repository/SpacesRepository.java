package com.allstate.compozed.repository;

import com.allstate.compozed.domain.Spaces;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by localadmin on 3/14/17.
 */
public interface SpacesRepository extends CrudRepository<Spaces,Long> {


}
