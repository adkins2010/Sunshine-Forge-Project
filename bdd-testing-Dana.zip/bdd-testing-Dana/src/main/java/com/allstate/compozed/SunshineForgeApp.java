package com.allstate.compozed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SunshineForgeApp {

	public static void main(String[] args) {
		SpringApplication.run(SunshineForgeApp.class, args);
	}
}
