package com.allstate.compozed.repository;

import com.allstate.compozed.domain.App;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by localadmin on 3/15/17.
 */
public interface AppRepository extends CrudRepository<App,Long> {

}
